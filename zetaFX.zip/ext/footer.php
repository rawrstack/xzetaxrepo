<!-- FOOTER -->
	<footer id="footer">
		<div class="container">
				
			<div class="row middle" style="border-bottom:1px solid #C9C9C9">
				<div class="col-md-3 hidden-xs">
					<ul class="circle">
						<li><a href="markets/forex/forex-swap-rates">
						<span style="color:#505050;margin-bottom:5px;font-weight:bold;list-style:none;content:none;">Why ZetaFX</span>
						</a></li>
						<li><a href="why-thinkforex/mission">Mission</a></li>
						<li><a href="why-thinkforex/regulation">Regulation</a></li>
						<li><a href="why-thinkforex/technology">Technology</a></li>
						<li><a href="why-thinkforex/careers">Careers</a></li>
						<li><a href="why-thinkforex/forex-promotions/">Promotions</a></li>
						<li><a href="why-thinkforex/companynews/">Company News</a></li>
						<li><a href="why-thinkforex/awards">Awards</a></li>
						
					</ul>
				</div><!-- .col-md-7 -->
				<div class="col-md-3 hidden-xs">
					<ul class="circle">
						<li><a href="trading-platforms"><span style="color:#505050;margin-bottom:5px;font-weight:bold;list-style:none;content:none;">Platform</span></a></li>
						<li><a href="trading-platforms/metatrader-4">MetaTrader 4</a></li>
						<li><a href="trading-platforms/ctrader">cTrader</a></li>
						<li><a href="trading-platforms/mobile">Mobile Trading</a></li>
						<li><a href="trading-platforms/api-trading">API Trading</a></li>
						<li><a href="trading-tools">Trading Tools</a></li>
					
							<li><a href="market-analysis/"><span style="color:#505050;margin-bottom:5px;font-weight:bold;list-style:none;content:none;">Market Analysis</span></a></li>
						<li><a href="market-analysis/traders-corner/">Trader's Corner</a></li>
						<li><a href="market-analysis/analyst-corner">Meet the Analysts</a></li>
					
					</ul>
				</div>
				<div class="col-md-3 hidden-xs">
					<ul class="circle">
						<li><a href="education"><span style="color:#505050;margin-bottom:5px;font-weight:bold;">Education</span></a></li>
						<li><a href="education/trading-guides">Trading Guides</a></li>
						<li><a href="education/trader-survey">Trading Survey</a></li>
						<li><a href="markets"><span style="color:#505050;margin-bottom:5px;font-weight:bold;list-style:none;content:none;">Markets</span></a></li>
						<li><a href="markets/forex">Forex</a></li>
						<li><a href="markets/cfd-broker">CFDs</a></li>
						<li><a href="markets/metal-trading">Metal Trading</a></li>
						<li><a href="markets/contract-specifications">Contract Specs</a></li>
						<li><a href="markets/trading-account-types">Account Types</a></li>
					 </ul>
				</div>

				<div class="col-md-3 hidden-xs">
				    <ul class="circle">
						<li><a href="partnerships"><span style="color:#505050;margin-bottom:5px;font-weight:bold;list-style:none;content:none;">Partnership</span></a></li>
						<li><a href="partnerships/how-to-become-a-partner">Become a Partner</a></li>
						<li><a href="partnerships/introducing-broker-program">Introducing Broker</a></li>
						<li><a href="partnerships/forex-white-label-program">White Label</a></li>
						<li><a href="support"><span style="color:#505050;margin-bottom:5px;font-weight:bold;list-style:none;content:none;">Support</span></a></li>
						<li><a href="support/tfx-faq">ZetaFX FAQ</a></li>
						<li><a href="deposit-forex-funds">Deposit Funds</a></li>
						<li><a href="support/withdraw-forex-funds">Withdrawal of Funds</a></li>
						<li><a href="support/contact-us">Contact Us</a></li>
					</ul>
				 </div><!-- .col-md-5 --> 
                  
				
			</div><!-- .row -->
			
			

			 <div class="row middle" style="border-top:1px solid #FFFFFF;padding:31px 0;">
						 <div class="col-md-3">
							<p style="color:#505050;margin-bottom:5px;font-weight:bold;">Corporate Info</p>
									  <address style="margin:2px;color:#626262;">
									   Zeta Corporation Limited <br>
										Dept 400
										61 Praed Street<br>
										London United Kingdom,<br>
										W2 1NS<br>
										Company No. 08825032
										 </address>
						</div>
						<div class="col-md-3">
						<p style="color:#505050;margin-bottom:5px;font-weight:bold;" >Contact ZetaFX</p>
									 <strong>Support : </strong><a href="support@zetafx.com">support@zetafx.com</a><br>
									 <strong>Finance : </strong><a href="finance@zetafx.com">finance@zetafx.com</a><br>
									 <strong>Phone : </strong>  +44 20 6426 3440 <br>
									 <strong>Open Ticket : </strong> <a href="support.zetafx.com">Support Ticket</a>
						</div>
						<div class="col-md-3">
								   <p style="color:#505050;margin-bottom:5px;font-weight:bold;">Follow ZetaFX</p>
									<ul class="social pull-left" style="margin:0;">
										<li><a href="#" class="google"></a></li>
										<li><a href="#" class="youtube"></a></li>
										<li><a href="#" class="facebook"></a></li>
										<li><a href="#" class="twitter"></a></li>
									</ul>
						</div>
						<div class="col-md-3">
						
						</div>
			 </div>
		</div>
		
		
		<div class="credits">
		
		<div class="container" style="text-align:start;">
		  
           <div class="row">
				<div class="col-sm-12">
				<h5 style="color:white;margin:5px 38px;">We accept</h5>
				<img src="img/uploads/paysecure.png" >
				</div>
			</div>

<p>
<b>Risk Warning :</b> Trading foreign exchange on margin carries high potential rewards but also high potential risks that may not be suitable for all investors. Before deciding to trade foreign exchange, you should carefully consider your investment objectives, level of experience and risk appetite. Past performance is not indicative of future results, which can vary due to market volatility. The possibility exists that you could sustain a loss of some or all of your initial investment and therefore you should not invest money that you cannot afford to lose. You should be aware of all the risks associated with foreign exchange trading and seek advice from an independent financial advisor if you have any doubts.
</p>
<p>
Contracts for Difference (CFDs) are complex financial products that are traded on margin. Trading CFDs carries a high level of risk since leverage can work both to your advantage and disadvantage. As a result, CFDs may not be suitable for all investors because you may lose all your invested capital. You should not risk more than you are prepared to lose. Before deciding to trade, you need to ensure that you understand the risks involved taking into account your investment objectives and level of experience. Past performance of CFDs is not a reliable indicator of future results. Most CFDs have no set maturity date. Hence, a CFD position matures on the date you choose to close an existing open position. Seek independent advice, if necessary. Please contact our Expert Account Manager.
</p>

<strong style="color:#F9F9F9">
  	&copy; Copyright 2014.  Zeta Corporation Limited. All Rights Reserved . 
</strong>
<div class="clear"></div>
		
		
		<div> <a href="legal-info.php">LEGAL INFORMATION<span>|</span><a href="privacy-policy.php">PRIVACY POLICY</a><span>|</span><a href="risk-disclosure.php">RISK DISCLOSURE</a><span>|</span><a href="aml-policy.php">AML POLICY</a></div>
		
		</div>
		
		
		</div>
	</footer>