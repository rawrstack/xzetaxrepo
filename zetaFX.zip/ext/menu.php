<header id="header">
					<aside class="topbar">
				<div class="container">

					<ul class="touch" style="display:none;">
					<li><a href="#" title="Frequently Answer question">FAQ</a> |</li>
					<li><a href="#" title="Open Ticket">Helpdesk</a> |</li>
					<li><a href="#" title="Contact Us">Contact Us</a> </li>
						
					</ul><!-- .touch -->

					<ul class="user-nav">
					
					<li>
							<i class="icomoon-mail2"></i>
							<a href="mailto:support@zetafx.com">support@zetafx.com</a> | 
					</li>
					<li><a href="#" title="Frequently Answer question">FAQ</a> |</li>
					<li><a href="#" title="Open Ticket">Helpdesk</a> |</li>
					<li><a href="#" title="Contact Us">Contact Us</a>&nbsp;&nbsp; </li>
						<li><a class="btn btn-round btn-medium" href="http://customer.zetafx.com/" target="_blank" title="Cabinet Pages" ><i class="fa fa-unlock-o"></i>  &nbsp;<span style="text-transform:capitalize;">ZetaFX </span><b>Cabinet</b></a></li>
						
						
					</ul><!-- .user-nav -->

					<ul class="user-nav" style="display:none;">
						<li><a href="#" title="John Doe"><img src="img/users/johndoe_avatar.jpg" alt="John Doe" title="John Doe"></a></li>
						<li><a href="#" title="John Doe">John Doe</a> | </li>
						<li><a href="#" title="Log Out">Log out</a></li>
					</ul><!-- .user-nav -->

				

				</div><!-- .container -->
			</aside><!-- .topbar -->
				<div class="navbar">
			<div class="container">

							
				
				<div class="navbar-inner">

					<a href="index.php" class="logo" >
						<img src="img/mainlogozeta.png" alt="Jets">
					</a><!-- .logo -->

					<ul id="mobile-menu">
						<li><a href="href="http://customer.zetafx.com/" target="_blank""  title="Log in">Create<strong> Account</strong></a></li>
						<li><a href="href="http://customer.zetafx.com/" target="_blank"" title="Cabinet">ZetaFX <b>Cabinet</b></a></li>
						<li><a class="btn-navbar" href="#"><i class="fa fa-reorder"></i></a></li>
												
					</ul><!-- #mobile-menu -->

					<ul id="main-menu" class="nav slide megamenu-width  carret">
						
						<li><a href="about-us.php">About<span>Who is ZetaFX?</span></a>
							<ul class="dropdown">
							    <li><a href="about-us.php">About Us</a></li>
								<li><a href="whyzetafx.php">Why ZetaFX</a></li>
								<li><a href="https://www.facebook.com/pages/Zetafx/720991231255655">Social</a></li>
								<li><a href="partners.php">Partners</a></li>
								<li><a href="#">ZetaFX Regulations</a></li>
							</ul>
						</li>
						<li><a href="#">Trading<span>The best deal offered</span></a>
							<ul class="dropdown">
							    <li><a href="account-types.php">Account Types</a></li>
								<li><a href="instruments.php">Instruments</a>
								<ul class="dropdown">
									<li>
									<a href="#">Forex Trading </a>
									</li>
									<li>
									<a href="#">CFDs </a>
									</li>
									<li>
									<a href="#">Precious Metals</a>
									</li>
								</ul>
								
								
								</li>
								<li><a href="trading-leverage.php">Trading Leverage</a></li>
								<li><a href="#">Open Trading Account</a></li>
								<li><a href="trial-account.php">Demo Account</a></li>
							</ul>
						</li>
						<li class="megamenu"><a href="#">Platforms<span>MetaTrader 4</span></a>
							<ul class="dropdown megamenu-category">
								<li>
									<div class="row">
										<div class="col-md-3">

											<nav class="category-nav">
												<ul>
													<li class=""><a href="#">Zeta MT4 Windows</a></li>
													<li><a href="#">Zeta MT4 for Mac</a></li>
													<li><a href="#">Zeta MT4 for Mobile</a></li>
												</ul>
											</nav><!-- .category-nav" -->

										</div><!-- .col-md-3 -->
										<div class="col-md-9">

											<div class="category-content">
												<div class="current">

													<div class="title">
														<h4>MetaTrader 4 (MT4)</h4>
													</div><!-- .title -->

													<div class="text">
														<p><i>MT4 is a popular, advanced and easily accessible trading platform. As one of the largest MT4 brokers in the world, we have the scope to provide you with a unique trading experience.</i></p>
													</div><!-- .text -->
													
													<div class="row">
														<div class="col-xs-6">

															<a href="#" class="iconbox">
																<div class="iconbox-heading">
																	<div class="icon">
																		<img src="img/icons/terminalicon.png"  title="MT4 Terminal">
																	</div>
																	<div class="title">
																		<button class="btn btn-medium btn-red" type="button">MT4 Terminal</button>
																	</div>
																</div><!-- .iconbox-heading -->
															</a><!-- .iconbox -->

														</div><!-- .col-xs-4 -->
														<div class="col-xs-6">

															<a href="#" class="iconbox">
																<div class="iconbox-heading">
																	<div class="icon">
																		<img src="img/icons/multiterminalicon.png"  title="MT4 Terminal">
																	</div>
																	<div class="title">
																		<button class="btn btn-medium btn-red" type="button">MT4 Multi Terminal</button>
																	</div>
																</div><!-- .iconbox-heading -->
															</a><!-- .iconbox -->

														</div><!-- .col-xs-4 -->
														
													</div><!-- .row -->
													
												</div>
												<div>
													<div class="title">
														<h4>MetaTrader 4 (MT4) For Mac</h4>
													</div><!-- .title -->
													<div class="text">
														<p><i>MetaTrader 4 was created and built for use on PCs, but now we provides you the ability to run MT4 directly on your Mac without the need for emulators or add-ons. You still benefit from the great range of features including charting and one click execution.</i></p>
													</div><!-- .text -->
													<hr />
													<div class="row">
														<div class="col-xs-12">

															<a href="#" class="iconbox">
																<div class="iconbox-heading">
																	<div class="icon">
																		<img src="img/icons/macmt4.png"  title="MT4 Terminal">
																	</div>
																	<div class="title">
																		<button class="btn btn-medium btn-red" type="button">Mac MT4 Terminal</button>
																	</div>
																</div><!-- .iconbox-heading -->
															</a><!-- .iconbox -->

														</div><!-- .col-xs-4 -->
														
													</div><!-- .row -->
													
												</div>
												<div>
													<div class="title">
														<h4>MT4 Terminal For Mobiles</h4>
													</div><!-- .title -->
													<div class="text">
														<p><i>MetaTrader 4 Mobile App lets you easily access your trading account on-the-go. View live streaming Forex quotes and CFDs, review your balance and equity, and trade on both live and demo accounts. Easily manage your positions or enter new trades on the fly. Get started by downloading the application for your mobile device now.</i></p>
													</div><!-- .text -->
													<hr />
													<div class="row">
														<div class="col-xs-6">

															<a href="https://play.google.com/store/apps/details?id=net.metaquotes.metatrader4&hl=en" target="blank_" class="iconbox">
																<div class="iconbox-heading">
																	<div class="icon">
																		<img src="img/icons/playstore-download-btn.png" alt="android" title="android">
																	</div>
																	
																</div><!-- .iconbox-heading -->
															</a><!-- .iconbox -->

														</div><!-- .col-xs-4 -->
														<div class="col-xs-6">

															<a href="https://itunes.apple.com/en/app/metatrader-4/id496212596" target="blank_" class="iconbox">
																<div class="iconbox-heading">
																	<div class="icon">
																		<img src="img/icons/appstore-download-btn.png" alt="apple ios" title="apple ios">
																	</div>
																	
																</div><!-- .iconbox-heading -->
															</a><!-- .iconbox -->

														</div><!-- .col-xs-4 -->
														
													</div><!-- .row -->
													
													
												</div>
											</div><!-- .category-content -->

										</div><!-- .col-md-9 -->
									</div>
								</li>
							</ul><!-- .megamenu-category -->
						</li>
						
						<li><a href="#">Educations<span>Form of learning</span></a>
							<ul class="dropdown">
								<li><a href="forex-glossary.php">Forex Glossary</a></li>
								<li><a href="trading-forex.php">Trading Forex</a></li>
								<li><a href="mt4-basics.php">Mt4 Basic</a></li>
								<li><a href="quick-start-guide.php">Quick Start Guide</a></li>
								
							</ul>
						</li>
						<li><a href="partnership.php">Partnership<span>Cooperate with ZetaFX</span></a>
							<ul class="dropdown">
							<li><a href="#">Agency</a></li>
							<li><a href="#">Master Introducing Broker (MIB)</a></li>
							<li><a href="ib-zetafx.php">Introducing Brokers (IB)</a></li>
							<li><a href="#">Fx Consultant</a></li>
							<li><a href="#">Fx Agent</a></li>
							<li><a href="white-label.php">White Label Solution</a></li>
								
								
							</ul>
						</li>
						<li><a href="#">Support<span>We accessible for 24/7</span></a>
							<ul class="dropdown">
								<li><a href="faq.php">FAQs</a></li>
								<li><a href="http://zetafx.com/support" target="_blank">Support Tickets</a></li>
								<li><a href="contact.php">Contact Us</a></li>
							</ul>
						</li>
						
					</ul><!-- #main-menu -->

				</div><!-- .navbar-inner -->

			</div><!-- .container -->
		</div><!-- .navbar -->
	</header><!-- #header -->