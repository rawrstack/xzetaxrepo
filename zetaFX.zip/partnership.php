
<!-- HEADER -->

<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->

<head>

	<!-- Basic -->
	<meta charset="utf-8">
	<title>ZetaFX - Home page</title>
	<meta name="keywords" content="HTML5 Template" />
	<meta name="description" content="Jets - Responsive HTML5 Template">
	<meta name="author" content="ZetaFX">

	<!-- Favicons -->
	<link rel="shortcut icon" type='image/x-icon' href="img/favicon.ico">
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="apple-touch-icon-144x144-precomposed.html">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="apple-touch-icon-114x114-precomposed.html">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="apple-touch-icon-72x72-precomposed.html">
	<link rel="apple-touch-icon-precomposed" href="apple-touch-icon-precomposed.html">


	<!-- Mobile Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap/bootstrap.css" />

	<!-- AWESOME and ICOMOON fonts -->
	<link rel="stylesheet" href="css/fonts/awesome/css/font-awesome.css">
	<link rel="stylesheet" href="css/fonts/icomoon/style.css">

	<!-- Theme CSS -->
	<link rel="stylesheet" href="js/library/slider-revolution/css/settings.css">
	<link rel="stylesheet" href="css/theme.css">
	<link rel="stylesheet" href="css/theme-elements.css">
	<link rel="stylesheet" href="css/color/purple.css" id="layout-color">

	<!-- Theme Options -->
	<link rel="stylesheet" href="css/customx.css">
	<link rel="stylesheet" href="css/fonts.css">
	<!-- Modernizr -->
	<script type="text/javascript" src="js/library/modernizr/modernizr.js"></script>

	<!--[if lte IE 8]>
		<link rel="stylesheet" href="css/ie8.css">
		<script src="js/library/respond-js/respond.src.js"></script>
	<![endif]-->

</head>
<body class="index" style="background:#ffffff">

	
	<!-- For mobile preview -->
	<script type="text/javascript">
		if ((window.location !== window.parent.location && !(/android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(navigator.userAgent.toLowerCase()))) == true) { document.body.style.overflowY = "scroll"; }
	</script>

	


			<!-- #header --><?php include 'ext/menu.php'; ?>


<div id="page-content" role="main">
	<div class="container">

		<!-- CONTENT -->
		<div id="content">
<header class="devider-bottom devider-heavy devider-margin-medium">
<h1>Partnerships</h1>
<p class="excerpt">Morbi mauris tortor, vulputate vel luctus nec, commodo non urna.Morbi mauris tortor, vulputate vel luctus nec,Morbi mauris tortor.</p>
</header>

			
		
				<div class="row">
				
				<h3>Partner with us, today !</h3>
					<p>We know our Partners and profoundly understand all their needs in respect of effective development and growth along with our Company. Becoming our Partner, you are incorporated into our Company so we’ll do our best to make your business develop together with us.</p>
                    <hr />
				<h3>Introducer Broker</h3>
					<p>Receive generous, customized compensation plans, a dedicated account manager and a full suite of marketing tools with advanced reporting providing detailed insight on conversion rates, commissions, and more</p>
					  <hr />
				<h3>White Label Solutions</h3>
					<p>Zeta FX White Label is the ideal place to start up your brokerage businesses as the irresistible service that comes with smooth & unnamed pricing from your respective liquidity providers to your clients in your name.</p>
					  <hr />
				<h3>FX Consultant</h3>
					<p>The FX Consultant program is your chance to step into a ready-made business opportunity on very favorable terms. It’s an opportunity to make money no matter where you are located and regardless of the timing and frequency of your clients’ trades.</p>
					  <hr />
				<h3>FX Agent</h3> 
					<p>We believes that every Client is our partner. Every Client can get commission from the trades of each of the Clients they have signed up. It is very easy to introduce new Clients using your own unique agent’s reference.</p>



					
				</div><!-- .row -->
				
			

		</div><!-- #content -->

	</div><!-- .container -->
</div><!-- #page-content -->

<!-- FOOTER --><?php include 'ext/footer.php'; ?>
	

	<!-- jQuery & Helper library -->
	<script type="text/javascript" src="js/library/jquery/jquery-1.10.2.min.js"></script>
	<script type="text/javascript">
		$('#main-menu li.current').parents('li').addClass('current');
	</script>
	<script type="text/javascript" src="js/library/helper/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/library/helper/jquery.touchSwipe.min.js"></script>
	<script type="text/javascript" src="js/library/helper/jquery.mousewheel.min.js"></script>
	<script type="text/javascript" src="js/library/helper/imagesloaded.pkgd.min.js"></script>

	<!-- Options -->
	<script type="text/javascript" src="js/jquery.cookie.js"></script>
	<script type="text/javascript" src="js/theme-options.js"></script>

	<!-- Retina js -->
	<script type="text/javascript" src="js/library/retina/retina.js"></script>

	<!-- FancyBox -->
	<script type="text/javascript" src="js/library/fancybox/jquery.fancybox.pack8cbb.js?v=2.1.5"></script>

	<!-- Bootstrap js -->
	<script type="text/javascript" src="js/library/bootstrap/bootstrap.min.js"></script>

	<!-- Validate -->
	<script type="text/javascript" src="js/library/validate/jquery.validate.min.js"></script>

	<!-- FlickrFeed  -->
	<script type="text/javascript" src="js/library/jFlickrFeed/jflickrfeed.min.js"></script>
	<!-- carouFredSel -->
	<script type="text/javascript" src="js/library/carouFredSel/jquery.carouFredSel-6.2.1-packed.js"></script>

	<!-- SLIDER REVOLUTION 4.x SCRIPTS  -->
	<script type="text/javascript" src="js/library/slider-revolution/js/jquery.themepunch.plugins.min.js"></script>
	<script type="text/javascript" src="js/library/slider-revolution/js/jquery.themepunch.revolution.min.js"></script>

	<!--scripts for current page -->
	<script type="text/javascript" src="js/page/home.js"></script>

	<!-- Main theme javaScript file -->
	<script type="text/javascript" src="js/theme.js"></script>

</body>
</html>
